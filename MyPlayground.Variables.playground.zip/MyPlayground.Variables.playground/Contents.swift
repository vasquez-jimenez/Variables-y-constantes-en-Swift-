//: Playground - noun: a place where people can play

import UIKit
//Variables

var saludo = "Hola"
print(saludo)

var nombre = "CSF"

print("Buen trabajo \(nombre)!")



var estadoDeAnimo = "Super feliz"
//Como se siente?
estadoDeAnimo = "Super feliz"
print("Usted se siente \(estadoDeAnimo) hoy.")



var estoyProgramandoEnIosPorPrimeraVez: String
estoyProgramandoEnIosPorPrimeraVez = "Hola Mundo"
print(estoyProgramandoEnIosPorPrimeraVez)


//Variables con numeros enteros
var miEdad: Int
miEdad = 20
print("Tengo \(miEdad) años.")

var laEdadDeFirulais: Int = 5
print("Mi perro tiene \(laEdadDeFirulais) años.")



